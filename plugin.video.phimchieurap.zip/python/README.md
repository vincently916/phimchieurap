# This is a collection of my Python solutons that I wrote for the excerises from http://www.practicepython.org/. It's a great site to learn Python.
